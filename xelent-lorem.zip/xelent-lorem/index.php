<?php
/**
/*
Plugin Name: Xelent Lorem
Plugin URI: http://wordpress.org/plugins/xelent-lorem
Description: Tanveer Bhutta Wordpress Developer.
Author: Tanveer Bhutta
Version: 1.0
Author URI: http://ma.tt/
*/

// define( 'PLUGIN_DIR_PATH', plugin_dir_path( _FILE_ ) );
// define( 'PLUGIN_URL', plugins_url() );
// define( 'PLUGIN_VERSION', '1.0' );


function custom_menu_page(){
    add_menu_page(
        'Xelent Lorem Title',
        'Xelent Lorem',
        'manage_options',
        'xelent-lorem',
        'custom_admin_view',
        'dashicons-admin-multisite',
        11
    );
    add_submenu_page(
   'xelent-lorem',
   'Add New',
   'Add New',
   'manage_options',
   'add-new',
   'add_new_function'
    );
    add_submenu_page(
   'xelent-lorem',
   'All Xelents',
   'All Xelents',
   'manage_options',
   'all-xelents',
   'add_new_functions'
    );

}
add_action( 'admin_menu', 'custom_menu_page' );
 
/**
 * Display a custom menu page
 */
function custom_admin_view(){
    esc_html_e( 'Custom Admin View Xelent', 'Tanveer' );  
}

function add_new_function(){
include_once  PLUGIN_DIR_PATH."/views/add-new.php";
}

function add_new_functions(){
echo 'This is My Secound Level Menu';
}

 function wc_auction_reports(){
  //include_once PLUGIN_DIR_PATH.'/views/add-new.php';
 }

// function tanveer_wp_enqueue_style() {
//     wp_enqueue_style( PLUGIN_URL.'/tanveer/assets/css/style.css',
//      '',
//      PLUGIN_VERSION
//       );
//     wp_enqueue_script( PLUGIN_URL.'/tanveer/assets/js/script.js',
//      '',
//      PLUGIN_VERSION,
//      false
//     );
// }
// add_action( 'init', 'tanveer_wp_enqueue_style' );


// table generating code
// function xelent_plugin_tables(){
// global $wpdb;
// require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

//   //if (count($wpdb->get_var('SHOW TABLES LIKE "wp_xelent"')) == 0){
//   $sql_query_to_create_table = "CREATE TABLE `wp_xelent` (
// `id` int(11) NOT NULL AUTO_INCREMENT,
// `name` varchar(150) NOT NULL,
// `email` varchar(150) NOT NULL,
// `phone` varchar(150) NOT NULL,
// `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
// PRIMARY KEY (`id`)
// ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"; /// sql query to create table

//   dbDelta($sql_query_to_create_table);
// }
// register_activation_hook( _FILE_, 'xelent_plugin_tables' );

// Delete table when deactivate
// function deactivate_table() {
//      global $wpdb;
//      $wp_xelent = "wp_xelent";
//      $sql = "DROP TABLE IF EXISTS $wp_xelent;";
//      $wpdb->query($sql);
// }    
// register_deactivation_hook( _FILE_, 'deactivate_table' );
// function register_my_custom_menu_page() {
//   add_menu_page( 'Custom Menu Page Title',
//   'Custom Menu Page',
//   'manage_options',
//   'custom.php',
//   '',
//   'dashicons-welcome-widgets-menus',
//   90
//  );
// }
 /**
 * Register a custom menu page.
 */
// function add_custom_menu(){
//     add_menu_page(
//         'customplugin',
//         'Tanveer Menu',
//         'manage_options',
//         'custom-plugin',
//         'custom_plugin_func',
//         'dashicons-images-alt',
//         9
//     );
//     add_submenu_page(
//         'custom-plugin',
//         'Add New',
//         'manage_options',
//         'custom-plugin',
//         'custom_plugin_func'
//     );
// }
// add_action( 'admin_menu', 'add_custom_menu' );

// function custom_plugin_func(){
//     esc_html_e( 'Tanveer  Page Test', 'tanveer' );  
// }
// add_action( 'admin_menu', 'register_my_custom_menu_page' );
 ?>